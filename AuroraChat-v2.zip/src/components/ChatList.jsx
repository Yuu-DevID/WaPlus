import { useState, useEffect, useCallback } from "react"
import { useChatStore } from "../store/chat"
import { useAppStore } from "../store/app"
import ChatItem from "./ChatItem"

const SearchIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
  </svg>
)
const PlusIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
  </svg>
)

const STATUS_LABEL = { connected: "Terhubung", reconnecting: "Menyambung...", failed: "Koneksi Gagal", connecting: "Menghubungkan..." }

function SkeletonItem() {
  return (
    <div style={{ display: "flex", gap: 11, padding: "9px 14px", alignItems: "center" }}>
      <div className="skel" style={{ width: 46, height: 46, borderRadius: "50%", flexShrink: 0 }} />
      <div style={{ flex: 1 }}>
        <div className="skel" style={{ width: "60%", height: 12, marginBottom: 7 }} />
        <div className="skel" style={{ width: "85%", height: 10 }} />
      </div>
    </div>
  )
}

export default function ChatList({ connStatus }) {
  const { chats, contacts, loadChats } = useChatStore()
  const { activeJid, setActiveJid, navTab } = useAppStore()
  const [search, setSearch] = useState("")
  const [filter, setFilter] = useState("all")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadChats().finally(() => setLoading(false))
  }, [])

  const status = connStatus || "connecting"

  let items = navTab === "contacts" ? contacts : chats

  // Search filter
  if (search) {
    const q = search.toLowerCase()
    items = items.filter(c => (c.name || "").toLowerCase().includes(q) || (c.jid || "").includes(q) || (c.last_msg || "").toLowerCase().includes(q))
  }

  // Tab filter
  if (filter === "unread") items = items.filter(c => c.unread_count > 0)
  if (filter === "groups") items = items.filter(c => c.is_group || (c.jid || "").endsWith("@g.us"))

  const handleClick = useCallback((jid) => { setActiveJid(jid) }, [])

  return (
    <div className="chat-panel">
      {/* Header */}
      <div className="chat-panel-header">
        <div className="chat-panel-title-row">
          <div className="chat-panel-title">
            <div className={"conn-dot " + status} />
            {navTab === "contacts" ? "Kontak" : "Pesan"}
          </div>
          <button
            style={{ width: 30, height: 30, borderRadius: 8, background: "rgba(37,211,102,.1)", border: "1px solid rgba(37,211,102,.2)", color: "var(--green)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}
            title="Chat Baru"
          >
            <PlusIcon />
          </button>
        </div>

        {/* Connection status text */}
        <div style={{ fontSize: 11, color: status === "connected" ? "var(--green)" : status === "failed" ? "var(--text-danger)" : "var(--text-warn)", marginBottom: 8, display: "flex", alignItems: "center", gap: 5 }}>
          {STATUS_LABEL[status] || "Menghubungkan..."}
          {status === "reconnecting" && <span className="spinner spinner-sm" style={{ borderTopColor: "var(--text-warn)", borderColor: "rgba(251,191,36,.2)" }} />}
        </div>

        {/* Search */}
        <div className="search-wrap">
          <div className="search-icon"><SearchIcon /></div>
          <input
            className="search-input"
            placeholder="Cari pesan atau kontak..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Filters */}
      {navTab !== "contacts" && (
        <div className="filter-row">
          {[{ id: "all", label: "Semua" }, { id: "unread", label: "Belum Baca" }, { id: "groups", label: "Grup" }].map(f => (
            <button key={f.id} className={"filter-btn" + (filter === f.id ? " active" : "")} onClick={() => setFilter(f.id)}>
              {f.label}
            </button>
          ))}
        </div>
      )}

      {/* List */}
      <div className="chat-list">
        {loading ? (
          Array.from({ length: 8 }).map((_, i) => <SkeletonItem key={i} />)
        ) : items.length === 0 ? (
          <div style={{ textAlign: "center", padding: "40px 20px", color: "var(--text-3)" }}>
            <div style={{ fontSize: 36, marginBottom: 10 }}>
              {search ? "🔍" : navTab === "contacts" ? "👥" : "💬"}
            </div>
            <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4, color: "var(--text-2)" }}>
              {search ? "Tidak ada hasil" : navTab === "contacts" ? "Belum ada kontak" : "Belum ada pesan"}
            </div>
            <div style={{ fontSize: 11 }}>
              {search ? "Coba kata kunci lain" : "Mulai chat baru dengan tombol + di atas"}
            </div>
          </div>
        ) : (
          <>
            {items.map(item => (
              <ChatItem
                key={item.jid}
                chat={item}
                active={activeJid === item.jid}
                onClick={() => handleClick(item.jid)}
                isContact={navTab === "contacts"}
              />
            ))}
          </>
        )}
      </div>
    </div>
  )
}
