import { create } from "zustand"

export const useChatStore = create((set, get) => ({
    // Chat list
    chats: [],
    chatsTotal: 0,
    chatsLoading: false,
    chatsPage: 0,

    // Messages keyed by JID: { [jid]: Message[] }
    messages: {},
    messagesLoading: false,
    messagesPage: {},

    // Contacts
    contacts: [],
    contactsTotal: 0,

    // ── Chat actions ────────────────────────────────
    setChats: (chats, total) => set({ chats, chatsTotal: total }),
    prependChats: (more) => set((s) => ({ chats: [...s.chats, ...more] })),
    setChatsLoading: (v) => set({ chatsLoading: v }),

    loadChats: async () => {
        set({ chatsLoading: true })

        try {
            const result = await window.api.getChats()
            set({
                chats: result.chats,
                chatsTotal: result.total,
                chatsLoading: false
            })
        } catch (err) {
            console.error("Failed to load chats:", err)
            set({ chatsLoading: false })
        }
    },

    upsertChat: (chat) => set((s) => {
        const idx = s.chats.findIndex(c => c.jid === chat.jid)
        if (idx >= 0) {
            const updated = [...s.chats]
            updated[idx] = { ...updated[idx], ...chat }
            return { chats: updated.sort((a, b) => (b.pinned - a.pinned) || (b.last_msg_at - a.last_msg_at)) }
        }
        return { chats: [chat, ...s.chats] }
    }),

    // ── Message actions ─────────────────────────────
    setMessages: (jid, msgs) => set((s) => ({
        messages: { ...s.messages, [jid]: msgs }
    })),
    appendMessage: (jid, msg) => set((s) => {
        const existing = s.messages[jid] || []
        if (existing.some(m => m.id === msg.id)) return s
        return { messages: { ...s.messages, [jid]: [...existing, msg] } }
    }),
    setMessagesLoading: (v) => set({ messagesLoading: v }),

    // ── Contact actions ─────────────────────────────
    setContacts: (contacts, total) => set({ contacts, contactsTotal: total }),
}))
