const { contextBridge, ipcRenderer } = require("electron")

contextBridge.exposeInMainWorld("api", {
  // ── Auth Actions ───────────────────────────────
  requestPairing: (phone) => ipcRenderer.send("auth:request-pairing", phone),
  startQRMode: () => ipcRenderer.send("auth:start-qr"),
  logout: () => ipcRenderer.send("auth:logout"),
  forceReconnect: () => ipcRenderer.send("connection:force-reconnect"),

  // ── Auth Events ────────────────────────────────
  onPairingCode: (cb) => ipcRenderer.on("auth:pairing-code", (_e, d) => cb(d)),
  onPairingError: (cb) => ipcRenderer.on("auth:pairing-error", (_e, d) => cb(d)),
  onQR: (cb) => ipcRenderer.on("auth:qr", (_e, d) => cb(d)),
  onConnected: (cb) => ipcRenderer.on("connection:open", (_e, d) => cb(d)),
  onNeedPhone: (cb) => ipcRenderer.on("auth:need-phone-number", (_e) => cb()),
  onLoggedOut: (cb) => ipcRenderer.on("auth:logged-out", (_e) => cb()),

  // ── Connection Events ──────────────────────────
  onConnectionClose: (cb) => ipcRenderer.on("connection:close", (_e, d) => cb(d)),
  onReconnecting: (cb) => ipcRenderer.on("connection:reconnecting", (_e, d) => cb(d)),
  onConnectionFailed: (cb) => ipcRenderer.on("connection:failed", (_e, d) => cb(d)),
  onConnectionError: (cb) => ipcRenderer.on("connection:error", (_e, d) => cb(d)),

  // ── DB: Chats ──────────────────────────────────
  dbChats: (opts) => ipcRenderer.invoke("db:chats:list", opts),
  dbSearch: (query) => ipcRenderer.invoke("db:chats:search", { query }),
  dbMarkRead: ({ jid }) => ipcRenderer.invoke("db:chats:read", { jid }),
  dbPinChat: ({ jid, pinned }) => ipcRenderer.invoke("db:chats:pin", { jid, pinned }),
  dbArchive: ({ jid, archived }) => ipcRenderer.invoke("db:chats:archive", { jid, archived }),

  // ── DB: Contacts ───────────────────────────────
  dbContacts: (opts) => ipcRenderer.invoke("db:contacts:list", opts),
  dbSearchContacts: (query) => ipcRenderer.invoke("db:contacts:search", { query }),

  // ── DB: Messages ───────────────────────────────
  dbMessages: ({ jid, limit, offset }) => ipcRenderer.invoke("db:messages:list", { jid, limit, offset }),
  dbSearchMsgs: ({ jid, query }) => ipcRenderer.invoke("db:messages:search", { jid, query }),

  // ── DB: Stats ─────────────────────────────────
  dbStats: () => ipcRenderer.invoke("db:stats"),

  // ── Messaging ─────────────────────────────────
  sendMessage: ({ jid, body, type }) => ipcRenderer.invoke("msg:send", { jid, body, type }),

  // ── Live DB update events ──────────────────────
  onChatsUpdated: (cb) => ipcRenderer.on("db:chats:updated", (_e) => cb()),
  onContactsUpdated: (cb) => ipcRenderer.on("db:contacts:updated", (_e) => cb()),
  onNewMessage: (cb) => ipcRenderer.on("db:messages:new", (_e, d) => cb(d)),
})