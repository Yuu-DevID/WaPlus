// ╔═══════════════════════════════════════════════════════════╗
// ║              AuroraChat — Baileys Client                  ║
// ║            WhatsApp Desktop Connection Layer              ║
// ║                                                           ║
// ║  Dipanggil dari: electron/main.js                         ║
// ║                                                           ║
// ║  IPC Events yang di-emit ke renderer:                     ║
// ║    auth:need-phone-number  → perlu input nomor            ║
// ║    auth:qr                 → QR code (string)             ║
// ║    auth:pairing-code       → { code, phone }              ║
// ║    auth:pairing-error      → { message }                  ║
// ║    auth:logged-out         → null                         ║
// ║    connection:open         → { name, jid, phone }         ║
// ║    connection:close        → { statusCode, reason }       ║
// ║    connection:reconnecting → { attempt, maxAttempt, ms }  ║
// ║    connection:failed       → { attempts }                 ║
// ║    connection:error        → { message }                  ║
// ║    messages:new            → MessagePayload               ║
// ╚═══════════════════════════════════════════════════════════╝

"use strict"

const {
  makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  isJidBroadcast,
  isJidGroup,
  isJidStatusBroadcast,
  jidNormalizedUser,
  downloadMediaMessage,
  proto,
} = require("baileys")

const { Boom } = require("@hapi/boom")
const pino = require("pino")
const chalk = require("chalk")
const path = require("path")
const fs = require("fs")
const NodeCache = require("node-cache")

// ════════════════════════════════════════════════════════════
// CONFIG
// ════════════════════════════════════════════════════════════

const CONFIG = {
  SESSION_DIR: path.resolve(__dirname, "./session"),
  // mode: "pairing" | "qr" — ditentukan dari UI
  // default pairing, bisa diubah saat runtime
  AUTH_MODE: "pairing",
  MAX_RECONNECT: 10,
  RECONNECT_BASE_MS: 2000,
  RECONNECT_MAX_MS: 30000,
  RECONNECT_JITTER_MS: 1500,
  SYNC_FULL_HISTORY: true,   // match working example
  MSG_CACHE_TTL: 300,
  MSG_CACHE_MAX: 1000,
}

// ════════════════════════════════════════════════════════════
// STATE
// ════════════════════════════════════════════════════════════

let sock = null
let mainWindow = null
let reconnectAttempts = 0
let reconnectTimer = null
let isLoggedOut = false
let isConnected = false
let pendingPhone = null   // nomor yang menunggu pairing
let authMode = CONFIG.AUTH_MODE

const msgRetryCache = new NodeCache({
  stdTTL: CONFIG.MSG_CACHE_TTL,
  maxKeys: CONFIG.MSG_CACHE_MAX,
})

// ════════════════════════════════════════════════════════════
// LOGGER
// ════════════════════════════════════════════════════════════

const logger = pino({
  level: process.env.BAILEYS_LOG || "silent",
})

// ════════════════════════════════════════════════════════════
// HELPERS
// ════════════════════════════════════════════════════════════

function send(channel, data) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    try {
      mainWindow.webContents.send(channel, data)
    } catch (_) { }
  }
}

const tag = (c, t) => chalk[c].bold(`[ ${t} ]`)
const log = (m) => console.log(tag("cyan", "AuroraChat"), chalk.white(m))
const logOk = (m) => console.log(tag("green", "AuroraChat"), chalk.green(m))
const logW = (m) => console.log(tag("yellow", "AuroraChat"), chalk.yellow(m))
const logE = (m) => console.error(tag("red", "AuroraChat"), chalk.red(m))

/**
 * Normalisasi nomor — input dari UI sudah termasuk country code
 * Contoh: "628577001732", "18001234567"
 * Fallback: jika dimulai 0, tambah 62 (Indonesia)
 */
function normalizePhone(raw) {
  let n = String(raw).replace(/[\s\-\+\(\)]/g, "")
  if (n.startsWith("0")) n = "62" + n.slice(1)
  return n
}

function extractBody(message) {
  if (!message) return ""
  return (
    message.conversation ||
    message.extendedTextMessage?.text ||
    message.imageMessage?.caption ||
    message.videoMessage?.caption ||
    message.documentMessage?.caption ||
    message.audioMessage?.caption ||
    message.buttonsResponseMessage?.selectedButtonId ||
    message.listResponseMessage?.title ||
    message.templateButtonReplyMessage?.selectedId ||
    ""
  )
}

function calcDelay(attempt) {
  const base = CONFIG.RECONNECT_BASE_MS * Math.pow(2, attempt - 1)
  const capped = Math.min(base, CONFIG.RECONNECT_MAX_MS)
  const jitter = Math.floor(Math.random() * CONFIG.RECONNECT_JITTER_MS)
  return capped + jitter
}

function assertConnected() {
  if (!sock) throw new Error("Tidak ada koneksi aktif ke WhatsApp")
}

// ════════════════════════════════════════════════════════════
// CLEANUP
// ════════════════════════════════════════════════════════════

function cleanupSocket() {
  if (!sock) return
  try {
    sock.ev.removeAllListeners()
    sock.ws?.removeAllListeners()
  } catch (_) { }
  sock = null
  isConnected = false
}

// ════════════════════════════════════════════════════════════
// KONEKSI UTAMA
// ════════════════════════════════════════════════════════════

async function connectToWhatsApp(phoneForPairing = null) {
  if (isLoggedOut) {
    logW("Tidak reconnect — akun telah logout")
    return
  }

  if (!fs.existsSync(CONFIG.SESSION_DIR)) {
    fs.mkdirSync(CONFIG.SESSION_DIR, { recursive: true })
  }

  // ── Load Auth State ──────────────────────────────────
  let state, saveCreds
  try {
    const auth = await useMultiFileAuthState(CONFIG.SESSION_DIR)
    state = auth.state
    saveCreds = auth.saveCreds
  } catch (err) {
    logE(`Gagal load auth state: ${err.message}`)
    send("connection:error", { message: `Gagal baca session: ${err.message}` })
    return
  }

  // ── Fetch Versi WA Terbaru ───────────────────────────
  let version, isLatest
  try {
    ; ({ version, isLatest } = await fetchLatestBaileysVersion())
  } catch (_) {
    logW("Gagal fetch versi WA terbaru — pakai fallback")
    version = [2, 3000, 1023141118]
    isLatest = false
  }

  log(`Baileys WA v${version.join(".")} | isLatest: ${isLatest}`)

  // ── Cleanup socket sebelumnya ────────────────────────
  cleanupSocket()

  // ── Tentukan mode berdasarkan apakah ada phoneForPairing ──
  const usePairingMode = !!phoneForPairing

  // ════════════════════════════════════════════════════════
  // PENTING: Browser identifier HARUS sesuai dengan
  // yang dikenali WhatsApp agar pairing berhasil!
  // Mengikuti contoh yang berhasil:
  // ['Ubuntu', 'Chrome', '20.0.04']
  // ════════════════════════════════════════════════════════
  sock = makeWASocket({
    logger,
    version,
    auth: state,
    printQRInTerminal: false,
    browser: ['Ubuntu', 'Chrome', '20.0.04'],
    syncFullHistory: CONFIG.SYNC_FULL_HISTORY,
    generateHighQualityLinkPreview: true,
    msgRetryCounterCache: msgRetryCache,
    getMessage: async (key) => {
      const cached = msgRetryCache.get(key.id)
      if (cached) return cached
      return proto.Message.fromObject({})
    },
  })

  // ════════════════════════════════════════════════════════
  // PAIRING CODE — request SEGERA setelah socket dibuat
  // (sama seperti contoh yang berhasil)
  // ════════════════════════════════════════════════════════
  if (usePairingMode && !sock.authState.creds.registered) {
    const cleaned = normalizePhone(phoneForPairing)
    log(`Mode Pairing — nomor: ${cleaned}`)

    // Delay kecil agar socket siap terlebih dulu
    await new Promise(r => setTimeout(r, 3000))

    try {
      const code = await sock.requestPairingCode(cleaned)
      logOk(`Pairing Code: ${code}`)
      send("auth:pairing-code", { code, phone: cleaned })
    } catch (err) {
      logE(`Gagal request pairing code: ${err.message}`)
      send("auth:pairing-error", { message: err.message })
    }
  } else if (!usePairingMode && !sock.authState.creds.registered) {
    log("Mode QR — menunggu scan dari HP")
    // QR akan dikirim melalui event connection.update
  }

  // ════════════════════════════════════════════════════════
  // EVENT: connection.update
  // ════════════════════════════════════════════════════════
  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update

    // QR code — kirim ke renderer untuk ditampilkan
    if (qr) {
      log("QR Code diterima → kirim ke renderer")
      send("auth:qr", qr)
    }

    // ── OPEN ─────────────────────────────────────────
    if (connection === "open") {
      isConnected = true
      reconnectAttempts = 0
      isLoggedOut = false
      pendingPhone = null

      if (reconnectTimer) {
        clearTimeout(reconnectTimer)
        reconnectTimer = null
      }

      const me = sock.user
      logOk(`Terhubung sebagai: ${me?.name} | ${me?.id}`)
      send("connection:open", {
        name: me?.name || "Unknown",
        jid: me?.id || "",
        phone: me?.id?.split(":")[0] || "",
      })
    }

    // ── CLOSE ────────────────────────────────────────
    if (connection === "close") {
      isConnected = false

      const boom = new Boom(lastDisconnect?.error)
      const statusCode = boom?.output?.statusCode ?? -1
      const reason = (
        Object.entries(DisconnectReason).find(([, v]) => v === statusCode)?.[0]
        ?? "Unknown"
      )

      logE(`Koneksi terputus — code: ${statusCode} (${reason})`)
      send("connection:close", { statusCode, reason })

      // LOGOUT
      if (statusCode === DisconnectReason.loggedOut) {
        isLoggedOut = true
        logW("Akun di-logout — menghapus session...")
        send("auth:logged-out", null)
        await clearSession()
        return
      }

      // RESTART REQUIRED
      if (statusCode === DisconnectReason.restartRequired) {
        logW("Restart required — reconnect langsung...")
        scheduleReconnect(0)
        return
      }

      // MULTIDEVICE MISMATCH
      if (statusCode === DisconnectReason.multideviceMismatch) {
        logW("Multidevice mismatch — reconnect...")
        scheduleReconnect(0)
        return
      }

      // ERROR UMUM — reconnect
      const retriable = [
        DisconnectReason.connectionClosed,
        DisconnectReason.connectionLost,
        DisconnectReason.connectionReplaced,
        DisconnectReason.timedOut,
        DisconnectReason.unavailableService,
        DisconnectReason.badSession,
        408, 500, 503, -1,
      ]

      if (retriable.includes(statusCode)) {
        scheduleReconnect()
      } else {
        logW(`Status ${statusCode} tidak perlu reconnect otomatis`)
        send("connection:failed", { statusCode, reason })
      }
    }
  })

  // ── Save creds ───────────────────────────────────────
  sock.ev.on("creds.update", saveCreds)

  // ── Messages ─────────────────────────────────────────
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return

    for (const msg of messages) {
      if (!msg.message) continue
      if (isJidStatusBroadcast(msg.key.remoteJid || "")) continue
      if (isJidBroadcast(msg.key.remoteJid || "")) continue

      const jid = msg.key.remoteJid || ""
      const isGroup = isJidGroup(jid)
      const isMe = msg.key.fromMe
      const pushname = msg.pushName || "Unknown"
      const body = extractBody(msg.message)
      const msgType = Object.keys(msg.message)[0] || "unknown"

      if (msg.message) {
        msgRetryCache.set(msg.key.id, msg.message)
      }

      if (!isMe && body) {
        const colors = ["green", "yellow", "magenta", "cyan", "blue"]
        const c = colors[Math.floor(Math.random() * colors.length)]
        console.log(
          tag("green", "MSG"),
          chalk[c](`${pushname} (${jid})`),
          chalk.white("→"),
          chalk.white(body.length > 120 ? body.slice(0, 120) + "…" : body)
        )
      }

      send("messages:new", {
        key: msg.key,
        message: msg.message,
        body,
        msgType,
        jid,
        sender: isMe ? (sock.user?.id ?? "") : (msg.participant || jid),
        pushname,
        isGroup,
        isMe,
        timestamp: Number(msg.messageTimestamp) || Math.floor(Date.now() / 1000),
        status: msg.status ?? 0,
        starred: msg.starred ?? false,
        broadcast: msg.broadcast ?? false,
        hasMedia: ["imageMessage", "videoMessage", "audioMessage", "documentMessage", "stickerMessage"].includes(msgType),
      })
    }

    // Handler case.js (opsional)
    try {
      const handler = require("./case")
      await handler(sock, { messages, type })
    } catch (e) {
      if (e.code !== "MODULE_NOT_FOUND") {
        logE(`Error di case handler: ${e.message}`)
      }
    }
  })

  // ── Other events ─────────────────────────────────────
  sock.ev.on("messages.update", (updates) => send("messages:update", updates))
  sock.ev.on("message-receipt.update", (updates) => send("messages:receipt", updates))
  sock.ev.on("messages.delete", (item) => send("messages:delete", item))
  sock.ev.on("messages.reaction", (reactions) => send("messages:reaction", reactions))

  sock.ev.on("chats.set", ({ chats, isLatest: il }) => {
    log(`Loaded ${chats.length} chats (isLatest: ${il})`)
    send("chats:set", chats)
  })
  sock.ev.on("chats.upsert", (c) => send("chats:upsert", c))
  sock.ev.on("chats.update", (u) => send("chats:update", u))
  sock.ev.on("chats.delete", (i) => send("chats:delete", i))

  sock.ev.on("contacts.set", ({ contacts }) => {
    log(`Loaded ${contacts.length} contacts`)
    send("contacts:set", contacts)
  })
  sock.ev.on("contacts.upsert", (c) => send("contacts:upsert", c))
  sock.ev.on("contacts.update", (u) => send("contacts:update", u))

  sock.ev.on("presence.update", ({ id, presences }) => send("presence:update", { id, presences }))
  sock.ev.on("groups.update", (u) => send("groups:update", u))
  sock.ev.on("group-participants.update", ({ id, participants, action }) => {
    send("groups:participants", { id, participants, action })
  })
  sock.ev.on("call", (calls) => send("call:incoming", calls))
  sock.ev.on("labels.association", (a) => send("labels:association", a))
  sock.ev.on("labels.edit", (l) => send("labels:edit", l))

  return sock
}

// ════════════════════════════════════════════════════════════
// RECONNECT LOGIC
// ════════════════════════════════════════════════════════════

function scheduleReconnect(overrideDelayMs) {
  if (isLoggedOut) return

  if (reconnectTimer) {
    clearTimeout(reconnectTimer)
    reconnectTimer = null
  }

  reconnectAttempts++

  if (reconnectAttempts > CONFIG.MAX_RECONNECT) {
    logE(`Gagal reconnect setelah ${CONFIG.MAX_RECONNECT}x. Berhenti.`)
    send("connection:failed", { attempts: reconnectAttempts - 1 })
    reconnectAttempts = 0
    return
  }

  const delay = overrideDelayMs !== undefined ? overrideDelayMs : calcDelay(reconnectAttempts)

  logW(
    `↺ Reconnect ke-${reconnectAttempts}/${CONFIG.MAX_RECONNECT}` +
    ` dalam ${(delay / 1000).toFixed(1)}s...`
  )

  send("connection:reconnecting", {
    attempt: reconnectAttempts,
    maxAttempt: CONFIG.MAX_RECONNECT,
    delayMs: delay,
  })

  reconnectTimer = setTimeout(async () => {
    reconnectTimer = null
    try {
      await connectToWhatsApp()
    } catch (err) {
      logE(`Error saat reconnect: ${err.message}`)
      scheduleReconnect()
    }
  }, delay)
}

async function forceReconnect() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer)
    reconnectTimer = null
  }
  reconnectAttempts = 0
  isLoggedOut = false
  logW("Force reconnect dipanggil dari UI")
  await connectToWhatsApp()
}

// ════════════════════════════════════════════════════════════
// SESSION
// ════════════════════════════════════════════════════════════

async function clearSession() {
  cleanupSocket()
  try {
    if (fs.existsSync(CONFIG.SESSION_DIR)) {
      const files = fs.readdirSync(CONFIG.SESSION_DIR)
      for (const f of files) {
        fs.rmSync(path.join(CONFIG.SESSION_DIR, f), { recursive: true, force: true })
      }
    }
    log("Session berhasil dihapus")
  } catch (err) {
    logE(`Gagal hapus session: ${err.message}`)
  }
}

// ════════════════════════════════════════════════════════════
// PUBLIC: INIT
// ════════════════════════════════════════════════════════════

/**
 * Init tanpa langsung konek.
 * Nanti UI yang memutuskan mau pairing atau QR.
 */
async function init(win) {
  mainWindow = win
  isLoggedOut = false
  reconnectAttempts = 0

  // Cek apakah sudah ada session
  const sessionExists = fs.existsSync(CONFIG.SESSION_DIR) &&
    fs.readdirSync(CONFIG.SESSION_DIR).length > 0

  if (sessionExists) {
    // Ada session → langsung konek (reconnect otomatis)
    log("Session ditemukan — mencoba reconnect otomatis...")
    await connectToWhatsApp()
  } else {
    // Belum ada session → tunggu UI kirim nomor atau pilih QR
    log("Belum ada session — menunggu pilihan dari UI...")
    send("auth:need-phone-number", null)
  }
}

// ════════════════════════════════════════════════════════════
// PUBLIC: AUTH
// ════════════════════════════════════════════════════════════

/**
 * Request pairing code — MEMBUAT koneksi baru dengan phone number
 * Pola sama persis dengan contoh yang berhasil:
 * 1. Buat socket
 * 2. Langsung request pairing code
 */
async function requestPairingCode(phoneNumber) {
  const cleaned = normalizePhone(phoneNumber)
  if (cleaned.length < 10) {
    const errMsg = `Nomor tidak valid: ${cleaned}`
    logE(errMsg)
    send("auth:pairing-error", { message: errMsg })
    throw new Error(errMsg)
  }

  log(`Memulai proses pairing untuk: ${cleaned}`)

  // Cleanup + buat koneksi baru dengan nomor untuk pairing
  // Ini penting! Socket HARUS dibuat baru dan langsung request pairing
  cleanupSocket()
  await clearSession()
  pendingPhone = cleaned
  await connectToWhatsApp(cleaned)
}

/**
 * Mulai mode QR — buat koneksi tanpa pairing code
 */
async function startQRMode() {
  log("Memulai mode QR Code...")
  cleanupSocket()
  await clearSession()
  authMode = "qr"
  await connectToWhatsApp(null) // null = QR mode
}

// ════════════════════════════════════════════════════════════
// PUBLIC: SEND MESSAGES
// ════════════════════════════════════════════════════════════

async function sendTextMessage(jid, text, opts = {}) {
  assertConnected()
  const payload = {
    text,
    ...(opts.mentions?.length ? { mentions: opts.mentions } : {}),
  }
  return await sock.sendMessage(jid, payload, opts.quoted ? { quoted: opts.quoted } : {})
}

async function sendImage(jid, image, caption = "", quoted = null) {
  assertConnected()
  const src = typeof image === "string" ? { url: image } : image
  return await sock.sendMessage(jid, { image: src, caption }, quoted ? { quoted } : {})
}

async function sendVideo(jid, video, caption = "", quoted = null) {
  assertConnected()
  const src = typeof video === "string" ? { url: video } : video
  return await sock.sendMessage(jid, { video: src, caption }, quoted ? { quoted } : {})
}

async function sendAudio(jid, audio, ptt = false, quoted = null) {
  assertConnected()
  const src = typeof audio === "string" ? { url: audio } : audio
  return await sock.sendMessage(jid, {
    audio: src,
    ptt,
    mimetype: ptt ? "audio/ogg; codecs=opus" : "audio/mp4",
  }, quoted ? { quoted } : {})
}

async function sendDocument(jid, document, fileName, mimetype = "application/octet-stream", caption = "", quoted = null) {
  assertConnected()
  const src = typeof document === "string" ? { url: document } : document
  return await sock.sendMessage(jid, {
    document: src,
    fileName,
    mimetype,
    caption,
  }, quoted ? { quoted } : {})
}

async function sendSticker(jid, sticker, quoted = null) {
  assertConnected()
  const src = typeof sticker === "string" ? { url: sticker } : sticker
  return await sock.sendMessage(jid, { sticker: src }, quoted ? { quoted } : {})
}

async function sendLocation(jid, lat, lng, name = "", address = "", quoted = null) {
  assertConnected()
  return await sock.sendMessage(jid, {
    location: { degreesLatitude: lat, degreesLongitude: lng, name, address },
  }, quoted ? { quoted } : {})
}

async function sendContact(jid, displayName, phoneNumber, quoted = null) {
  assertConnected()
  const num = normalizePhone(phoneNumber)
  const vcard =
    `BEGIN:VCARD\nVERSION:3.0\n` +
    `FN:${displayName}\n` +
    `TEL;type=CELL;type=VOICE;waid=${num}:+${num}\n` +
    `END:VCARD`
  return await sock.sendMessage(jid, {
    contacts: { displayName, contacts: [{ vcard }] },
  }, quoted ? { quoted } : {})
}

async function forwardMessage(jid, message) {
  assertConnected()
  return await sock.sendMessage(jid, { forward: message })
}

// ════════════════════════════════════════════════════════════
// PUBLIC: MESSAGE ACTIONS
// ════════════════════════════════════════════════════════════

async function deleteMessage(jid, msgKey, forEveryone = false) {
  assertConnected()
  if (forEveryone) {
    return await sock.sendMessage(jid, { delete: msgKey })
  }
  return await sock.chatModify({
    clear: {
      messages: [{ id: msgKey.id, fromMe: msgKey.fromMe, timestamp: Date.now() }],
    },
  }, jid)
}

async function reactToMessage(jid, msgKey, emoji) {
  assertConnected()
  return await sock.sendMessage(jid, { react: { text: emoji, key: msgKey } })
}

async function editMessage(jid, msgKey, newText) {
  assertConnected()
  return await sock.sendMessage(jid, { edit: msgKey, text: newText })
}

async function starMessage(jid, messages, star = true) {
  assertConnected()
  return await sock.chatModify({ star: { messages, star } }, jid)
}

// ════════════════════════════════════════════════════════════
// PUBLIC: CHAT MANAGEMENT
// ════════════════════════════════════════════════════════════

async function markRead(jid, msgIds, participant = null) {
  assertConnected()
  const keys = msgIds.map((id) => ({
    remoteJid: jid,
    id,
    ...(participant ? { participant } : {}),
  }))
  await sock.readMessages(keys)
}

async function markUnread(jid) {
  assertConnected()
  await sock.chatModify({
    markRead: false,
    lastMessages: [{ key: { remoteJid: jid }, messageTimestamp: Date.now() }],
  }, jid)
}

async function archiveChat(jid, archive = true) {
  assertConnected()
  await sock.chatModify({
    archive,
    lastMessages: [{ key: { remoteJid: jid }, messageTimestamp: Date.now() }],
  }, jid)
}

async function pinChat(jid, pin = true) {
  assertConnected()
  await sock.chatModify({ pin }, jid)
}

async function muteChat(jid, muteEndMs = null) {
  assertConnected()
  await sock.chatModify({ mute: muteEndMs ?? -1 }, jid)
}

async function deleteChat(jid, lastMsgId, lastMsgFromMe, lastMsgTimestamp) {
  assertConnected()
  await sock.chatModify({
    delete: true,
    lastMessages: [{
      key: { remoteJid: jid, id: lastMsgId, fromMe: lastMsgFromMe },
      messageTimestamp: lastMsgTimestamp,
    }],
  }, jid)
}

// ════════════════════════════════════════════════════════════
// PUBLIC: PRESENCE
// ════════════════════════════════════════════════════════════

async function sendPresenceUpdate(jid, type = "composing") {
  assertConnected()
  await sock.sendPresenceUpdate(type, jid)
}

async function subscribePresence(jid) {
  assertConnected()
  await sock.presenceSubscribe(jid)
}

// ════════════════════════════════════════════════════════════
// PUBLIC: PROFILE
// ════════════════════════════════════════════════════════════

async function getContactInfo(jid) {
  assertConnected()
  const normalized = jidNormalizedUser(jid)
  const [statusRes, imgRes] = await Promise.allSettled([
    sock.fetchStatus(normalized),
    sock.profilePictureUrl(normalized, "image"),
  ])
  return {
    status: statusRes.status === "fulfilled" ? statusRes.value?.status || "" : "",
    imgUrl: imgRes.status === "fulfilled" ? imgRes.value : null,
  }
}

async function updateMyStatus(status) {
  assertConnected()
  await sock.updateProfileStatus(status)
}

async function updateMyName(name) {
  assertConnected()
  await sock.updateProfileName(name)
}

// ════════════════════════════════════════════════════════════
// PUBLIC: GROUP
// ════════════════════════════════════════════════════════════

async function getGroupMetadata(jid) {
  assertConnected()
  return await sock.groupMetadata(jid)
}

async function createGroup(name, participants) {
  assertConnected()
  return await sock.groupCreate(name, participants)
}

async function addGroupParticipants(jid, participants) {
  assertConnected()
  return await sock.groupParticipantsUpdate(jid, participants, "add")
}

async function removeGroupParticipants(jid, participants) {
  assertConnected()
  return await sock.groupParticipantsUpdate(jid, participants, "remove")
}

async function updateGroupAdmin(jid, participants, action) {
  assertConnected()
  return await sock.groupParticipantsUpdate(jid, participants, action)
}

async function leaveGroup(jid) {
  assertConnected()
  await sock.groupLeave(jid)
}

async function updateGroupDescription(jid, description) {
  assertConnected()
  await sock.groupUpdateDescription(jid, description)
}

async function updateGroupName(jid, name) {
  assertConnected()
  await sock.groupUpdateSubject(jid, name)
}

async function getGroupInviteLink(jid) {
  assertConnected()
  return await sock.groupInviteCode(jid)
}

// ════════════════════════════════════════════════════════════
// PUBLIC: MEDIA
// ════════════════════════════════════════════════════════════

async function downloadMedia(message, type = "buffer") {
  return await downloadMediaMessage(message, type, {}, {
    logger,
    reuploadRequest: sock?.updateMediaMessage,
  })
}

// ════════════════════════════════════════════════════════════
// PUBLIC: MISC
// ════════════════════════════════════════════════════════════

async function blockContact(jid, action = "block") {
  assertConnected()
  await sock.updateBlockStatus(jid, action)
}

async function checkNumberExists(phoneNumber) {
  assertConnected()
  const cleaned = normalizePhone(phoneNumber)
  const [result] = await sock.onWhatsApp(cleaned)
  return {
    exists: result?.exists ?? false,
    jid: result?.jid ?? null,
  }
}

async function logout() {
  isLoggedOut = true
  if (reconnectTimer) {
    clearTimeout(reconnectTimer)
    reconnectTimer = null
  }
  try {
    if (sock) await sock.logout()
  } catch (_) { }
  await clearSession()
  logW("Logout berhasil")
  send("auth:logged-out", null)
}

function getSocket() {
  return sock
}

function getConnectionStatus() {
  return {
    connected: isConnected,
    reconnecting: reconnectTimer !== null,
    reconnectAttempts,
    loggedOut: isLoggedOut,
  }
}

// ════════════════════════════════════════════════════════════
// EXPORT
// ════════════════════════════════════════════════════════════

module.exports = {
  init,
  forceReconnect,
  getSocket,
  getConnectionStatus,

  requestPairingCode,
  startQRMode,
  logout,
  clearSession,

  sendTextMessage,
  sendImage,
  sendVideo,
  sendAudio,
  sendDocument,
  sendSticker,
  sendLocation,
  sendContact,
  forwardMessage,

  deleteMessage,
  reactToMessage,
  editMessage,
  starMessage,

  markRead,
  markUnread,
  archiveChat,
  pinChat,
  muteChat,
  deleteChat,

  sendPresenceUpdate,
  subscribePresence,

  getContactInfo,
  updateMyStatus,
  updateMyName,

  getGroupMetadata,
  createGroup,
  addGroupParticipants,
  removeGroupParticipants,
  updateGroupAdmin,
  leaveGroup,
  updateGroupDescription,
  updateGroupName,
  getGroupInviteLink,

  downloadMedia,

  blockContact,
  checkNumberExists,
  normalizePhone,
  extractBody,
}