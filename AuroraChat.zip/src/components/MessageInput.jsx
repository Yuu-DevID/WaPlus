import { useState, useRef, useCallback } from "react"
import { useChatStore } from "../store/chat"

// ── Icons ──────────────────────────────────────────
const EmojiIcon = () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" />
        <path d="M8 14s1.5 2 4 2 4-2 4-2" />
        <line x1="9" y1="9" x2="9.01" y2="9" />
        <line x1="15" y1="9" x2="15.01" y2="9" />
    </svg>
)

const AttachIcon = () => (
    <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
    </svg>
)

const MicIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
        <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
        <line x1="12" y1="19" x2="12" y2="23" />
        <line x1="8" y1="23" x2="16" y2="23" />
    </svg>
)

const SendIcon = () => (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="currentColor">
        <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
    </svg>
)

export default function MessageInput({ chatJid }) {
    const [text, setText] = useState("")
    const [sending, setSending] = useState(false)
    const textareaRef = useRef(null)
    const { appendMessage } = useChatStore()

    const hasText = text.trim().length > 0

    // Auto-grow textarea
    const handleChange = (e) => {
        setText(e.target.value)
        const el = e.target
        el.style.height = "auto"
        el.style.height = Math.min(el.scrollHeight, 140) + "px"
    }

    const send = useCallback(async () => {
        const body = text.trim()
        if (!body || sending) return
        setText("")
        if (textareaRef.current) { textareaRef.current.style.height = "44px" }
        setSending(true)
        try {
            if (window.api?.sendMessage) {
                const res = await window.api.sendMessage({ jid: chatJid, body })
                if (res?.ok && res.message) {
                    appendMessage(chatJid, {
                        id: res.message.id || Date.now().toString(),
                        chat_jid: chatJid,
                        body,
                        msg_type: "conversation",
                        timestamp: Math.floor(Date.now() / 1000),
                        from_me: 1,
                        status: 1,
                    })
                }
            } else {
                // Dev mode: optimistic append
                appendMessage(chatJid, {
                    id: Date.now().toString(),
                    chat_jid: chatJid,
                    body,
                    msg_type: "conversation",
                    timestamp: Math.floor(Date.now() / 1000),
                    from_me: 1,
                    status: 1,
                })
            }
        } catch (e) { console.error("Send error:", e) }
        finally { setSending(false); textareaRef.current?.focus() }
    }, [text, chatJid, sending])

    const handleKeyDown = (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault()
            send()
        }
    }

    return (
        <div className="flex items-end gap-2.5">
            {/* Emoji */}
            <button className="w-10 h-10 rounded-full flex items-center justify-center text-text-muted hover:text-text-secondary hover:bg-bg-hover transition-all flex-shrink-0">
                <EmojiIcon />
            </button>

            {/* Attach */}
            <button className="w-10 h-10 rounded-full flex items-center justify-center text-text-muted hover:text-text-secondary hover:bg-bg-hover transition-all flex-shrink-0">
                <AttachIcon />
            </button>

            {/* Text input */}
            <textarea
                ref={textareaRef}
                className="msg-input"
                rows={1}
                value={text}
                onChange={handleChange}
                onKeyDown={handleKeyDown}
                placeholder="Ketik pesan..."
                disabled={sending}
            />

            {/* Send / Mic */}
            {hasText ? (
                <button
                    onClick={send}
                    disabled={sending}
                    className="w-11 h-11 rounded-full flex items-center justify-center transition-all text-black flex-shrink-0 disabled:opacity-60"
                    style={{ background: "linear-gradient(135deg,#25d366,#1da851)", boxShadow: "0 3px 12px rgba(37,211,102,0.35)" }}>
                    {sending ? <div className="spinner spinner-sm" /> : <SendIcon />}
                </button>
            ) : (
                <button className="w-11 h-11 rounded-full flex items-center justify-center text-text-muted hover:text-text-secondary hover:bg-bg-hover transition-all flex-shrink-0">
                    <MicIcon />
                </button>
            )}
        </div>
    )
}
