import { useMemo } from "react"
import { formatDistanceToNowStrict, format, isToday, isYesterday } from "date-fns"
import { id as idLocale } from "date-fns/locale"

// ── Avatar helpers ─────────────────────────────────
const AVATAR_COLORS = [
    "#2e7d5e", "#1565c0", "#6a1b9a", "#c62828", "#e65100",
    "#2e7d32", "#00695c", "#558b2f", "#4527a0", "#00838f"
]
function getAvatarColor(str) {
    if (!str) return AVATAR_COLORS[0]
    let h = 0; for (let i = 0; i < str.length; i++) h = str.charCodeAt(i) + ((h << 5) - h)
    return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length]
}
function getInitials(name) {
    if (!name) return "?"
    return name.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase()
}

function Avatar({ name, size = 44 }) {
    return (
        <div className="avatar flex-shrink-0" style={{
            width: size, height: size,
            background: getAvatarColor(name),
            fontSize: size < 36 ? 12 : 15,
            color: "#fff"
        }}>
            {getInitials(name)}
        </div>
    )
}

// ── Time helpers ───────────────────────────────────
function formatChatTime(ts) {
    if (!ts) return ""
    const d = new Date(ts * 1000)
    if (isToday(d)) return format(d, "HH:mm")
    if (isYesterday(d)) return "Kemarin"
    return format(d, "dd/MM/yy")
}

// ── Media icon helper ──────────────────────────────
const MediaIcons = {
    image: "🖼️",
    video: "🎬",
    audio: "🎵",
    document: "📄",
    sticker: "🎭",
    location: "📍",
    poll: "📊",
    reaction: "❤️",
}

function lastMsgPreview(chat) {
    const t = chat.last_msg_type
    if (!t || t === "conversation" || t === "extendedTextMessage") {
        return chat.last_msg || ""
    }
    const icon = MediaIcons[t] || "📎"
    return `${icon} ${t.charAt(0).toUpperCase() + t.slice(1)}`
}

// ── Status ticks ───────────────────────────────────
function Ticks({ status }) {
    if (status === undefined || status === null) return null
    // 0=sending, 1=sent, 2=delivered, 3=read
    if (status === 0) return <span className="tick sent text-[10px]">⏱</span>
    if (status === 1) return <span className="tick sent">✓</span>
    if (status === 2) return <span className="tick sent">✓✓</span>
    return <span className="tick read">✓✓</span>
}

// ── Main ChatItem ──────────────────────────────────
export default function ChatItem({ chat, active, onClick, isContact }) {
    const name = chat.name || chat.phone || chat.jid?.split("@")[0] || "Unknown"
    const preview = isContact ? (chat.phone || chat.jid?.split("@")[0] || "") : lastMsgPreview(chat)
    const timeStr = !isContact ? formatChatTime(chat.last_msg_at) : ""
    const hasUnread = !isContact && chat.unread_count > 0
    const isMuted = chat.muted_until > Date.now() / 1000
    const isGroup = chat.is_group || chat.jid?.endsWith("@g.us")
    const isPinned = chat.pinned

    return (
        <div className={`chat-item ${active ? "active" : ""}`} onClick={onClick}>
            {/* Avatar */}
            <div className="relative flex-shrink-0">
                <Avatar name={name} size={44} />
                {isGroup && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-bg-secondary rounded-full flex items-center justify-center text-[9px]">👥</span>
                )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2 mb-0.5">
                    <span className="text-[13.5px] font-semibold text-text-primary truncate flex items-center gap-1.5">
                        {name}
                        {isMuted && <span className="text-[10px] text-text-muted">🔕</span>}
                        {isPinned && !isContact && <span className="text-[10px] text-text-muted">📌</span>}
                    </span>
                    <div className="flex items-center gap-1 flex-shrink-0">
                        {!isContact && chat.last_msg_type !== "conversation" && chat.from_me === 1 && (
                            <Ticks status={chat.last_status} />
                        )}
                        <span className={`text-[11px] ${hasUnread ? "text-green-text font-medium" : "text-text-muted"}`}>
                            {timeStr}
                        </span>
                    </div>
                </div>

                <div className="flex items-center justify-between gap-2">
                    <p className={`text-xs truncate leading-snug ${hasUnread ? "text-text-secondary" : "text-text-muted"}`}>
                        {preview}
                    </p>
                    {hasUnread && (
                        <div className="unread-badge">
                            {chat.unread_count > 99 ? "99+" : chat.unread_count}
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}
