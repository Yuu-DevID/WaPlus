import { useState, useRef, useEffect, useMemo } from "react"
import { useAuthStore } from "../store/auth"
import COUNTRIES from "../data/countries"

export default function CountrySelect() {
  const { country, setCountry } = useAuthStore()
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState("")
  const ref = useRef(null)
  const searchRef = useRef(null)

  useEffect(() => {
    const handleClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) {
        setOpen(false)
        setSearch("")
      }
    }
    document.addEventListener("mousedown", handleClick)
    return () => document.removeEventListener("mousedown", handleClick)
  }, [])

  useEffect(() => {
    if (open && searchRef.current) searchRef.current.focus()
  }, [open])

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === "Escape") { setOpen(false); setSearch("") }
    }
    if (open) {
      document.addEventListener("keydown", handleKey)
      return () => document.removeEventListener("keydown", handleKey)
    }
  }, [open])

  const selected = COUNTRIES.find((c) => c.iso === (country?.iso || "ID")) || COUNTRIES[0]

  const filtered = useMemo(() => {
    if (!search.trim()) return COUNTRIES
    const q = search.toLowerCase()
    return COUNTRIES.filter(
      (c) => c.name.toLowerCase().includes(q) || c.dial.includes(q) || c.iso.toLowerCase().includes(q)
    )
  }, [search])

  const onSelect = (c) => { setCountry(c); setOpen(false); setSearch("") }

  return (
    <div ref={ref} className="relative w-[140px] shrink-0">
      {/* Trigger Button */}
      <button
        type="button"
        id="country-select-trigger"
        onClick={() => setOpen((v) => !v)}
        className={`w-full flex items-center gap-2 px-3 py-3 bg-bg-input border-[1.5px] rounded-xl cursor-pointer transition-all duration-150 text-text-primary text-sm font-medium
          ${open
            ? "border-green-primary shadow-[0_0_0_3px_rgba(37,211,102,0.25)]"
            : "border-border hover:border-green-primary/40 hover:bg-bg-hover"
          }`}
      >
        <img src={selected.flag} alt={selected.name} className="country-flag" loading="lazy" />
        <span className="text-green-text font-semibold text-sm">{selected.dial}</span>
        <svg
          className={`ml-auto w-4 h-4 text-text-muted transition-transform duration-150 ${open ? "rotate-180" : ""}`}
          viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>

      {/* Dropdown */}
      {open && (
        <div className="country-dropdown">
          <input
            ref={searchRef}
            type="text"
            className="w-full px-3 py-3 bg-bg-input border-none border-b border-border text-text-primary text-sm outline-none placeholder:text-text-muted"
            placeholder="🔍  Cari negara..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            id="country-search-input"
          />
          <div className="country-list">
            {filtered.length === 0 && (
              <div className="p-4 text-center text-text-muted text-sm">Tidak ditemukan</div>
            )}
            {filtered.map((c) => (
              <button
                key={c.iso}
                onClick={() => onSelect(c)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 border-none rounded-lg cursor-pointer transition-all duration-150 text-text-primary text-sm text-left
                  ${selected.iso === c.iso ? "bg-green-primary/10" : "bg-transparent hover:bg-bg-hover"}`}
              >
                <img src={c.flag} alt={c.name} className="country-flag" loading="lazy" />
                <span className="flex-1 font-medium truncate">{c.name}</span>
                <span className="text-xs text-text-muted font-semibold shrink-0">{c.dial}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}