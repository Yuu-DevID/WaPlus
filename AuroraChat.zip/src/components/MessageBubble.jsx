import { format } from "date-fns"
import { id as idLocale } from "date-fns/locale"

// ── Status ticks ───────────────────────────────────
function Ticks({ status }) {
    const s = Number(status)
    if (s === 0) return <span style={{ fontSize: 10, color: "var(--color-text-muted)" }}>⏱</span>
    if (s === 1) return <span className="tick sent text-[10px]">✓</span>
    if (s === 2) return <span className="tick sent text-[10px]">✓✓</span>
    return <span className="tick read text-[10px]">✓✓</span>
}

// ── Timestamp ──────────────────────────────────────
function MsgTime({ ts }) {
    if (!ts) return null
    return (
        <span style={{ fontSize: 10, color: "var(--color-text-muted)", flexShrink: 0 }}>
            {format(new Date(ts * 1000), "HH:mm")}
        </span>
    )
}

// ── Media type renderers ───────────────────────────
function ImageMsg({ body }) {
    return (
        <div className="bubble-media w-[220px] h-[160px] bg-bg-hover flex items-center justify-center rounded-xl text-4xl">
            🖼️
            {body && <p className="text-xs text-text-secondary mt-1 px-2">{body}</p>}
        </div>
    )
}

function VideoMsg({ body }) {
    return (
        <div className="bubble-media w-[220px] h-[140px] bg-bg-hover flex flex-col items-center justify-center rounded-xl gap-2">
            <div className="w-11 h-11 rounded-full bg-bg-input flex items-center justify-center text-2xl">🎬</div>
            <p className="text-xs text-text-muted">{body || "Video"}</p>
        </div>
    )
}

function AudioMsg() {
    return (
        <div className="flex items-center gap-3 px-2 py-1.5 min-w-[180px]">
            <div className="w-9 h-9 rounded-full bg-green-primary/20 flex items-center justify-center text-lg flex-shrink-0">🎵</div>
            <div className="flex-1">
                <div className="h-[3px] bg-bg-input rounded-full">
                    <div className="h-full w-1/3 bg-green-primary rounded-full" />
                </div>
            </div>
            <span className="text-xs text-text-muted">0:12</span>
        </div>
    )
}

function DocumentMsg({ body }) {
    return (
        <div className="flex items-center gap-3 px-2 py-2 min-w-[180px]">
            <div className="w-10 h-10 rounded-xl bg-accent-blue/20 flex items-center justify-center text-xl flex-shrink-0">📄</div>
            <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-text-primary truncate">{body || "Dokumen"}</p>
                <p className="text-[10px] text-text-muted mt-0.5">File</p>
            </div>
        </div>
    )
}

function StickerMsg() {
    return <div className="text-6xl p-1">🎭</div>
}

function LocationMsg({ body }) {
    return (
        <div className="w-[200px]">
            <div className="h-[100px] bg-bg-hover rounded-xl flex items-center justify-center text-3xl mb-2">📍</div>
            <p className="text-xs text-text-secondary px-1">{body || "Lokasi"}</p>
        </div>
    )
}

function PollMsg({ body }) {
    return (
        <div className="flex items-center gap-2 px-2 py-1">
            <span className="text-xl">📊</span>
            <div>
                <p className="text-xs font-medium text-text-primary">Polling</p>
                <p className="text-[10px] text-text-muted">{body || "Ketuk untuk melihat"}</p>
            </div>
        </div>
    )
}

function ReactionMsg({ body }) {
    return <div className="text-2xl px-1">{body || "❤️"}</div>
}

function QuotedMsg({ quotedText }) {
    if (!quotedText) return null
    return (
        <div className="border-l-2 border-green-primary/60 pl-2 mb-2 py-0.5 rounded-sm bg-black/10">
            <p className="text-[11px] text-text-muted italic line-clamp-2">{quotedText}</p>
        </div>
    )
}

// ── Main MessageBubble ─────────────────────────────
export default function MessageBubble({ msg }) {
    const isMe = msg.from_me === 1
    const type = msg.msg_type || "conversation"

    const renderContent = () => {
        switch (type) {
            case "imageMessage":
            case "image": return <ImageMsg body={msg.body} />
            case "videoMessage":
            case "video": return <VideoMsg body={msg.body} />
            case "audioMessage":
            case "audio":
            case "pttMessage": return <AudioMsg />
            case "documentMessage":
            case "document": return <DocumentMsg body={msg.body} />
            case "stickerMessage":
            case "sticker": return <StickerMsg />
            case "locationMessage":
            case "location": return <LocationMsg body={msg.body} />
            case "pollCreationMessage":
            case "poll": return <PollMsg body={msg.body} />
            case "reactionMessage":
            case "reaction": return <ReactionMsg body={msg.body} />
            default:
                return msg.body ? (
                    <p className="text-sm leading-relaxed whitespace-pre-wrap break-words" style={{ color: "var(--color-text-primary)" }}>
                        {msg.body}
                    </p>
                ) : (
                    <p className="text-xs italic" style={{ color: "var(--color-text-muted)" }}>[Pesan tidak didukung]</p>
                )
        }
    }

    const isMedia = !["conversation", "extendedTextMessage", ""].includes(type)
    const isReaction = type === "reactionMessage" || type === "reaction"
    const isSticker = type === "stickerMessage" || type === "sticker"

    return (
        <div className={`flex animate-msg-in ${isMe ? "justify-end" : "justify-start"} mb-0.5`}>
            {/* Sender avatar for groups */}
            {!isMe && msg.is_group && msg.sender_name && (
                <div className="w-6 h-6 rounded-full flex-shrink-0 mr-1.5 mt-auto mb-[-2px]"
                    style={{ background: "#1565c0", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, color: "#fff", fontWeight: 700 }}>
                    {msg.sender_name?.[0]?.toUpperCase() || "?"}
                </div>
            )}

            <div className={`max-w-[70%] ${isReaction || isSticker ? "" : (isMe ? "bubble-out" : "bubble-in")} px-${isMedia ? "1" : "3"} pt-${isMedia ? "1" : "2"} pb-1.5`}
                style={{ maxWidth: isReaction || isSticker ? undefined : "70%" }}>

                {/* Group sender name */}
                {!isMe && msg.is_group && msg.sender_name && (
                    <p className="text-[11px] font-semibold mb-1" style={{ color: "#4ade80" }}>{msg.sender_name}</p>
                )}

                {/* Quoted message */}
                {msg.quoted_id && <QuotedMsg quotedText="Pesan dikutip" />}

                {/* Content */}
                {renderContent()}

                {/* Footer: time + ticks */}
                {!isReaction && !isSticker && (
                    <div className={`flex items-center gap-1 mt-1 ${isMe ? "justify-end" : "justify-start"}`}>
                        <MsgTime ts={msg.timestamp} />
                        {isMe && <Ticks status={msg.status} />}
                    </div>
                )}
            </div>
        </div>
    )
}
