import { useEffect, useRef, useState } from "react"
import QRCode from "qrcode"

export default function QRDisplay({ data, loading }) {
    const canvasRef = useRef(null)
    const [renderError, setRenderError] = useState(false)

    useEffect(() => {
        if (!data || !canvasRef.current) return
        setRenderError(false)
        QRCode.toCanvas(canvasRef.current, data, {
            width: 260, margin: 2,
            color: { dark: "#0b1117", light: "#FFFFFF" },
            errorCorrectionLevel: "M",
        }).catch(() => setRenderError(true))
    }, [data])

    if (loading || !data) {
        return (
            <div className="flex flex-col items-center justify-center py-10 gap-4">
                <div className="w-[260px] h-[260px] bg-bg-secondary rounded-[18px] border border-border flex flex-col items-center justify-center gap-4">
                    <div className="spinner spinner-lg spinner-green" />
                    <p className="text-sm text-text-muted">Memuat QR Code...</p>
                </div>
                <p className="text-xs text-text-muted">Harap tunggu sebentar</p>
            </div>
        )
    }

    if (renderError) {
        return (
            <div className="flex flex-col items-center gap-3 py-8">
                <div className="w-[260px] h-[260px] bg-bg-secondary rounded-[18px] border border-red-error/30 flex items-center justify-center">
                    <p className="text-sm text-red-error text-center px-4">Gagal merender QR Code. <br />Coba refresh.</p>
                </div>
            </div>
        )
    }

    return (
        <div className="flex flex-col items-center gap-4">
            {/* Corner-bracket QR frame */}
            <div className="relative inline-flex">
                {/* tl corner */}
                <span className="absolute top-0 left-0 w-7 h-7 border-t-[3px] border-l-[3px] border-green-primary rounded-tl-xl pointer-events-none z-10" />
                {/* tr corner */}
                <span className="absolute top-0 right-0 w-7 h-7 border-t-[3px] border-r-[3px] border-green-primary rounded-tr-xl pointer-events-none z-10" />
                {/* bl corner */}
                <span className="absolute bottom-0 left-0 w-7 h-7 border-b-[3px] border-l-[3px] border-green-primary rounded-bl-xl pointer-events-none z-10" />
                {/* br corner */}
                <span className="absolute bottom-0 right-0 w-7 h-7 border-b-[3px] border-r-[3px] border-green-primary rounded-br-xl pointer-events-none z-10" />

                <div className="qr-container qr-pulse p-4">
                    <canvas ref={canvasRef} />
                </div>
            </div>

            <div className="text-center space-y-1">
                <p className="text-xs text-text-secondary">
                    Buka <span className="text-green-text font-medium">WhatsApp</span> di HP →{" "}
                    Setelan → Perangkat Tertaut
                </p>
                <p className="text-xs text-text-muted">
                    Ketuk <span className="text-green-text font-medium">"Tautkan Perangkat"</span> lalu scan QR di atas
                </p>
            </div>
        </div>
    )
}
