import { useAuthStore } from "../store/auth"
import { useAppStore } from "../store/app"

// ── Icons ──────────────────────────────────────────
const IconChats = () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
)

const IconContacts = () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
)

const IconSettings = () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
)

const IconLogout = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
        <polyline points="16 17 21 12 16 7" />
        <line x1="21" y1="12" x2="9" y2="12" />
    </svg>
)

// ── Avatar helper ──────────────────────────────────
function getInitials(name) {
    if (!name) return "?"
    return name.split(" ").slice(0, 2).map(w => w[0]).join("").toUpperCase()
}

const AVATAR_COLORS = [
    "#2e7d5e", "#1565c0", "#6a1b9a", "#c62828", "#e65100", "#2e7d32", "#00695c", "#558b2f", "#4527a0", "#00838f"
]

function getAvatarColor(str) {
    if (!str) return AVATAR_COLORS[0]
    let h = 0
    for (let i = 0; i < str.length; i++) h = str.charCodeAt(i) + ((h << 5) - h)
    return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length]
}

// ── Nav items ──────────────────────────────────────
const NAV = [
    { id: "chats", icon: <IconChats />, tip: "Pesan" },
    { id: "contacts", icon: <IconContacts />, tip: "Kontak" },
]

export default function Sidebar() {
    const { navTab, setNavTab } = useAppStore()
    const { connectedUser } = useAuthStore()

    const handleLogout = () => {
        if (window.confirm("Keluar dari AuroraChat?")) {
            window.api?.logout?.()
        }
    }

    const name = connectedUser?.name || connectedUser?.pushName || "Kamu"
    const color = getAvatarColor(name)

    return (
        <div className="w-[64px] flex-shrink-0 flex flex-col items-center py-3 gap-1 border-r border-border bg-bg-sidebar relative">
            {/* Logo */}
            <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3"
                style={{ background: "linear-gradient(135deg,#25d366,#1da851)", boxShadow: "0 3px 12px rgba(37,211,102,0.3)" }}>
                <svg viewBox="0 0 20 20" fill="none" width="18" height="18">
                    <path d="M10 1C5.03 1 1 5.03 1 10c0 1.66.45 3.2 1.23 4.54L1 19l4.6-1.2A8.97 8.97 0 0010 19c4.97 0 9-4.03 9-9s-4.03-9-9-9z" fill="white" fillOpacity=".9" />
                    <circle cx="7" cy="10" r="1.1" fill="#1da851" />
                    <circle cx="10" cy="10" r="1.1" fill="#1da851" />
                    <circle cx="13" cy="10" r="1.1" fill="#1da851" />
                </svg>
            </div>

            {/* Nav buttons */}
            {NAV.map(item => (
                <button
                    key={item.id}
                    className={`sidebar-btn tooltip ${navTab === item.id ? "active" : ""}`}
                    data-tip={item.tip}
                    onClick={() => setNavTab(item.id)}
                >
                    {item.icon}
                </button>
            ))}

            {/* Spacer */}
            <div className="flex-1" />

            {/* Settings */}
            <button className="sidebar-btn tooltip" data-tip="Pengaturan">
                <IconSettings />
            </button>

            {/* Logout */}
            <button className="sidebar-btn tooltip" data-tip="Keluar" onClick={handleLogout}>
                <IconLogout />
            </button>

            {/* Avatar */}
            <div className="mt-2 w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white cursor-pointer select-none"
                style={{ background: color, boxShadow: "0 0 0 2px rgba(37,211,102,0.3)" }}
                title={name}>
                {getInitials(name)}
            </div>
        </div>
    )
}
