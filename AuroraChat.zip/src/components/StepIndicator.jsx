import { useAuthStore } from "../store/auth"

const STEPS = [
  { number: 1, label: "Nomor WA" },
  { number: 2, label: "Pairing Code" },
  { number: 3, label: "Terhubung" },
]

export default function StepIndicator() {
  const { step } = useAuthStore()

  return (
    <div className="flex items-center justify-center gap-2 mb-8 px-5 py-3 bg-bg-secondary rounded-2xl border border-border animate-fade-in">
      {STEPS.map((s, i) => (
        <div key={s.number} className="flex items-center gap-2">
          <div className="flex items-center gap-2">
            <div
              className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-250
                ${step > s.number
                  ? "bg-green-primary text-black shadow-[0_0_12px_rgba(37,211,102,0.25)]"
                  : step === s.number
                    ? "bg-green-primary text-black shadow-[0_0_12px_rgba(37,211,102,0.25)]"
                    : "bg-bg-hover text-text-muted"
                }`}
            >
              {step > s.number ? (
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              ) : (
                s.number
              )}
            </div>
            <span className={`text-sm font-medium whitespace-nowrap ${step >= s.number ? "text-green-text" : "text-text-muted"}`}>
              {s.label}
            </span>
          </div>
          {i < STEPS.length - 1 && (
            <div className={`w-6 h-0.5 rounded-sm shrink-0 ${step > s.number ? "bg-green-primary" : "bg-border"}`} />
          )}
        </div>
      ))}
    </div>
  )
}
