import { useEffect, useRef, useState, useCallback } from "react"
import { useChatStore } from "../store/chat"
import { useAppStore } from "../store/app"
import { format, isToday, isYesterday } from "date-fns"
import { id as idLocale } from "date-fns/locale"
import MessageBubble from "./MessageBubble"
import MessageInput from "./MessageInput"

// ── Icons ─────────────────────────────────────────
const BackIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="15 18 9 12 15 6" />
    </svg>
)
const SearchIcon = () => (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
)
const InfoIcon = () => (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" /><line x1="12" y1="16" x2="12" y2="12" /><line x1="12" y1="8" x2="12.01" y2="8" />
    </svg>
)
const MoreIcon = () => (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="5" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="12" cy="19" r="1" />
    </svg>
)

// ── Avatar helpers ─────────────────────────────────
const COLORS = ["#2e7d5e", "#1565c0", "#6a1b9a", "#c62828", "#e65100", "#2e7d32", "#00695c", "#4527a0"]
function getColor(s) { let h = 0; for (let i = 0; i < (s || "").length; i++)h = s.charCodeAt(i) + ((h << 5) - h); return COLORS[Math.abs(h) % COLORS.length] }
function getInitials(n) { if (!n) return "?"; return n.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase() }

// ── Date separator label ───────────────────────────
function dateSepLabel(ts) {
    const d = new Date(ts * 1000)
    if (isToday(d)) return `Hari ini — ${format(d, "d MMM yyyy", { locale: idLocale })}`
    if (isYesterday(d)) return `Kemarin — ${format(d, "d MMM yyyy", { locale: idLocale })}`
    return format(d, "EEEE, d MMMM yyyy", { locale: idLocale })
}

// ── Group messages by date ─────────────────────────
function groupByDate(msgs) {
    const groups = []
    let lastDate = null
    for (const m of msgs) {
        const d = new Date((m.timestamp || 0) * 1000)
        const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`
        if (key !== lastDate) {
            groups.push({ type: "sep", key: key + "_sep", label: dateSepLabel(m.timestamp || 0) })
            lastDate = key
        }
        groups.push({ type: "msg", key: m.id || m.timestamp, msg: m })
    }
    return groups
}

export default function ChatWindow() {
    const { activeJid, setActiveJid, toggleRightPanel } = useAppStore()
    const { chats, messages, setMessages, setMessagesLoading, messagesLoading } = useChatStore()

    const [page, setPage] = useState(0)
    const [hasMore, setHasMore] = useState(true)
    const bottomRef = useRef(null)
    const scrollRef = useRef(null)

    const chat = chats.find(c => c.jid === activeJid) || { jid: activeJid, name: activeJid?.split("@")[0] || "Unknown" }
    const name = chat.name || chat.phone || chat.jid?.split("@")[0] || "Unknown"
    const chatMsgs = messages[activeJid] || []
    const groups = groupByDate([...chatMsgs].sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0)))

    // Load messages
    const loadMessages = useCallback(async (jid, limit = 50, offset = 0) => {
        setMessagesLoading(true)
        try {
            const res = await window.api?.dbMessages?.({ jid, limit, offset })
            if (res?.ok) {
                const sorted = [...res.data].sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0))
                if (offset === 0) setMessages(jid, sorted)
                else setMessages(jid, [...sorted, ...(messages[jid] || [])])
                setHasMore(res.data.length === limit)
            }
        } catch (e) { console.error("loadMessages:", e) }
        finally { setMessagesLoading(false) }
    }, [messages])

    useEffect(() => {
        if (!activeJid) return
        setPage(0)
        setHasMore(true)
        loadMessages(activeJid, 50, 0)
        // Mark as read
        window.api?.dbMarkRead?.({ jid: activeJid })
    }, [activeJid])

    // Scroll to bottom on new messages
    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: "smooth" })
    }, [chatMsgs.length])

    // Infinite scroll up
    const handleScroll = useCallback(async () => {
        const el = scrollRef.current
        if (!el || el.scrollTop > 80 || !hasMore || messagesLoading) return
        const nextPage = page + 1
        setPage(nextPage)
        await loadMessages(activeJid, 50, nextPage * 50)
    }, [page, hasMore, messagesLoading, activeJid])

    return (
        <div className="flex flex-col h-full">
            {/* ── Header ──────────────────────────────────── */}
            <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-bg-sidebar flex-shrink-0">
                {/* Back button (for narrow windows) */}
                <button className="w-8 h-8 rounded-xl flex items-center justify-center text-text-muted hover:text-text-primary hover:bg-bg-hover transition-all md:hidden"
                    onClick={() => setActiveJid(null)}>
                    <BackIcon />
                </button>

                {/* Avatar */}
                <div className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                    style={{ background: getColor(name) }}>
                    {getInitials(name)}
                </div>

                {/* Name & status */}
                <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-bold text-text-primary truncate">{name}</h3>
                    <p className="text-[11px] text-green-text">
                        {chat.is_group ? `Grup` : ""}
                    </p>
                </div>

                {/* Action buttons */}
                <div className="flex items-center gap-1">
                    <button className="sidebar-btn" title="Cari pesan"><SearchIcon /></button>
                    <button className="sidebar-btn" title="Info kontak" onClick={toggleRightPanel}><InfoIcon /></button>
                    <button className="sidebar-btn" title="Lainnya"><MoreIcon /></button>
                </div>
            </div>

            {/* ── Message area ────────────────────────────── */}
            <div
                ref={scrollRef}
                onScroll={handleScroll}
                className="flex-1 overflow-y-auto p-4 space-y-1 chat-bg"
            >
                {/* Load more indicator */}
                {messagesLoading && page > 0 && (
                    <div className="flex justify-center py-2">
                        <div className="spinner spinner-sm spinner-green" />
                    </div>
                )}

                {/* Initial loading */}
                {messagesLoading && page === 0 && (
                    <div className="flex flex-col gap-3">
                        {[...Array(7)].map((_, i) => (
                            <div key={i} className={`flex ${i % 2 === 0 ? "justify-start" : "justify-end"}`}>
                                <div className="skeleton h-10 rounded-2xl" style={{ width: `${120 + (i * 37) % 140}px` }} />
                            </div>
                        ))}
                    </div>
                )}

                {/* Empty state */}
                {!messagesLoading && chatMsgs.length === 0 && (
                    <div className="flex flex-col items-center justify-center h-full gap-3 py-16">
                        <div className="text-4xl">💬</div>
                        <p className="text-sm text-text-muted">Belum ada pesan</p>
                        <p className="text-xs text-text-muted">Mulai percakapan sekarang</p>
                    </div>
                )}

                {/* Messages */}
                {groups.map(item => {
                    if (item.type === "sep") {
                        return (
                            <div key={item.key} className="date-sep py-3">
                                <span>{item.label}</span>
                            </div>
                        )
                    }
                    return (
                        <MessageBubble key={item.key} msg={item.msg} />
                    )
                })}

                <div ref={bottomRef} />
            </div>

            {/* ── Message input ────────────────────────────── */}
            <div className="flex-shrink-0 px-4 py-3 border-t border-border bg-bg-sidebar">
                <MessageInput chatJid={activeJid} />
            </div>
        </div>
    )
}
