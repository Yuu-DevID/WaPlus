import { useMemo } from "react"
import { useChatStore } from "../store/chat"
import { useAppStore } from "../store/app"

// ── Icons ──────────────────────────────────────────
const CloseIcon = () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
    </svg>
)
const BellIcon = () => (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.73 21a2 2 0 0 1-3.46 0" />
    </svg>
)
const SearchIcon = () => (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
)
const PinIcon = () => (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="12" y1="17" x2="12" y2="22" /><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V17z" />
    </svg>
)
const BlockIcon = () => (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" /><line x1="4.93" y1="4.93" x2="19.07" y2="19.07" />
    </svg>
)

// ── Avatar ─────────────────────────────────────────
const COLORS = ["#2e7d5e", "#1565c0", "#6a1b9a", "#c62828", "#e65100", "#2e7d32", "#00695c", "#4527a0"]
function getColor(s) { let h = 0; for (let i = 0; i < (s || "").length; i++)h = s.charCodeAt(i) + ((h << 5) - h); return COLORS[Math.abs(h) % COLORS.length] }
function getInitials(n) { if (!n) return "?"; return n.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase() }

// ── Media type icons/colors ────────────────────────
const MEDIA_PALETTE = [
    { bg: "#1565c0", icon: "📄" }, { bg: "#6a1b9a", icon: "🎵" },
    { bg: "#e65100", icon: "🎬" }, { bg: "#2e7d5e", icon: "🖼️" },
    { bg: "#4527a0", icon: "📌" }, { bg: "#c62828", icon: "❤️" },
]

export default function ContactPanel() {
    const { activeJid, setRightPanelOpen } = useAppStore()
    const { chats, messages } = useChatStore()

    const chat = chats.find(c => c.jid === activeJid) || { jid: activeJid }
    const name = chat.name || chat.phone || chat.jid?.split("@")[0] || "Unknown"
    const phone = chat.phone || chat.jid?.split("@")[0] || ""

    // Collect media messages
    const mediaMsgs = useMemo(() => {
        const msgs = messages[activeJid] || []
        return msgs.filter(m => m.has_media || ["imageMessage", "videoMessage", "audioMessage", "documentMessage", "image", "video", "audio", "document"].includes(m.msg_type))
    }, [messages, activeJid])

    const actionBtn = (icon, label, color = "text-text-secondary", danger = false) => (
        <button key={label}
            className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-bg-hover ${danger ? "text-red-error" : color}`}>
            <span className={danger ? "text-red-error" : "text-text-muted"}>{icon}</span>
            {label}
        </button>
    )

    return (
        <div className="flex flex-col h-full overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-border flex-shrink-0">
                <h3 className="text-sm font-bold text-text-primary">Info Kontak</h3>
                <button onClick={() => setRightPanelOpen(false)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-text-muted hover:text-text-primary hover:bg-bg-hover transition-all">
                    <CloseIcon />
                </button>
            </div>

            {/* Avatar & Name */}
            <div className="flex flex-col items-center py-8 px-4 border-b border-border">
                <div className="w-[78px] h-[78px] rounded-full flex items-center justify-center text-2xl font-bold text-white mb-4"
                    style={{ background: getColor(name), boxShadow: "0 4px 18px rgba(0,0,0,0.3)" }}>
                    {getInitials(name)}
                </div>
                <h2 className="text-base font-bold text-text-primary mb-1">{name}</h2>
                {phone && (
                    <p className="text-xs text-text-muted">+{phone.replace(/\D/g, "")}</p>
                )}
                <div className="flex items-center gap-1.5 mt-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-primary animate-pulse" />
                    <span className="text-xs text-green-text font-medium">online sekarang</span>
                </div>
            </div>

            {/* About */}
            <div className="px-4 py-4 border-b border-border">
                <p className="text-[11px] text-text-muted font-semibold uppercase tracking-wider mb-2">Tentang</p>
                <p className="text-sm text-text-secondary leading-relaxed">
                    {chat.is_group ? "Grup WhatsApp" : "Halo! Aku pakai WhatsApp."}
                </p>
            </div>

            {/* Media gallery */}
            <div className="px-4 py-4 border-b border-border">
                <div className="flex items-center justify-between mb-3">
                    <p className="text-[11px] text-text-muted font-semibold uppercase tracking-wider">
                        Media ({mediaMsgs.length})
                    </p>
                    {mediaMsgs.length > 4 && (
                        <button className="text-[11px] text-green-text hover:underline">Lihat semua</button>
                    )}
                </div>
                {mediaMsgs.length === 0 ? (
                    <p className="text-xs text-text-muted py-2">Belum ada media</p>
                ) : (
                    <div className="grid grid-cols-3 gap-1.5">
                        {MEDIA_PALETTE.slice(0, Math.min(6, mediaMsgs.length || 6)).map((m, i) => (
                            <div key={i}
                                className="aspect-square rounded-xl flex items-center justify-center text-xl cursor-pointer hover:opacity-80 transition-opacity relative overflow-hidden"
                                style={{ background: m.bg + "44" }}>
                                <span>{m.icon}</span>
                                {i === 5 && mediaMsgs.length > 6 && (
                                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                                        <span className="text-xs text-white font-bold">+{mediaMsgs.length - 6}</span>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Actions */}
            <div className="px-2 py-3">
                <p className="text-[11px] text-text-muted font-semibold uppercase tracking-wider px-2 mb-2">Aksi</p>
                <div className="space-y-0.5">
                    {actionBtn(<BellIcon />, "Bisukan Notifikasi")}
                    {actionBtn(<SearchIcon />, "Cari di Chat")}
                    {actionBtn(<PinIcon />, "Pin Chat")}
                    {actionBtn(<BlockIcon />, "Blokir Kontak", "", true)}
                </div>
            </div>
        </div>
    )
}
