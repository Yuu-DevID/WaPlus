import { useState, useRef, useEffect, useCallback, useMemo } from "react"
import { useChatStore } from "../store/chat"
import { useAppStore } from "../store/app"
import ChatItem from "./ChatItem"

const SearchIcon = () => (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
)

const EditIcon = () => (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
    </svg>
)

const FILTERS = [
    { id: "all", label: "Semua" },
    { id: "unread", label: "Belum Dibaca" },
    { id: "groups", label: "Grup" },
]

export default function ChatList() {
    const { chats, chatsLoading, contacts } = useChatStore()
    const { navTab, chatFilter, setChatFilter, activeJid, setActiveJid } = useAppStore()

    const [search, setSearch] = useState("")
    const [searchResults, setSearchResults] = useState(null)
    const [searching, setSearching] = useState(false)
    const debounceRef = useRef(null)

    // Debounced search
    const handleSearch = useCallback((val) => {
        setSearch(val)
        clearTimeout(debounceRef.current)
        if (!val.trim()) { setSearchResults(null); return }
        debounceRef.current = setTimeout(async () => {
            setSearching(true)
            try {
                const res = await window.api?.dbSearch?.(val.trim())
                if (res?.ok) setSearchResults(res.data)
                else setSearchResults([])
            } catch { setSearchResults([]) }
            finally { setSearching(false) }
        }, 280)
    }, [])

    // Build display list
    const displayList = useMemo(() => {
        let base = searchResults !== null ? searchResults : chats

        if (navTab === "contacts") {
            return contacts
        }

        if (chatFilter === "unread") base = base.filter(c => c.unread_count > 0)
        if (chatFilter === "groups") base = base.filter(c => c.is_group)
        return base
    }, [chats, contacts, searchResults, chatFilter, navTab])

    const pinned = displayList.filter(c => c.pinned && navTab === "chats")
    const recent = displayList.filter(c => !c.pinned || navTab !== "chats")

    const isContact = navTab === "contacts"

    return (
        <div className="flex flex-col h-full">
            {/* Header */}
            <div className="px-4 pt-4 pb-3 border-b border-border">
                <div className="flex items-center justify-between mb-3">
                    <h2 className="text-base font-bold text-text-primary">
                        {isContact ? "Kontak" : "Pesan"}
                    </h2>
                    <button className="w-8 h-8 rounded-xl flex items-center justify-center text-text-muted hover:text-text-primary hover:bg-bg-hover transition-all">
                        <EditIcon />
                    </button>
                </div>

                {/* Search input */}
                <div className="relative">
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none">
                        {searching ? <div className="spinner spinner-sm spinner-green" /> : <SearchIcon />}
                    </div>
                    <input
                        type="text"
                        value={search}
                        onChange={e => handleSearch(e.target.value)}
                        placeholder="Cari percakapan..."
                        className="w-full pl-9 pr-3 py-2.5 bg-bg-secondary border border-border rounded-xl text-sm text-text-primary placeholder:text-text-muted outline-none focus:border-green-primary/60 transition-colors"
                    />
                    {search && (
                        <button
                            onClick={() => handleSearch("")}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary text-lg leading-none">
                            ×
                        </button>
                    )}
                </div>
            </div>

            {/* Filter tabs — only for chats */}
            {!isContact && (
                <div className="flex gap-1.5 px-3 py-2.5 border-b border-border">
                    {FILTERS.map(f => (
                        <button
                            key={f.id}
                            onClick={() => setChatFilter(f.id)}
                            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all duration-150
                ${chatFilter === f.id
                                    ? "bg-green-primary/15 text-green-text border border-green-primary/30"
                                    : "text-text-muted hover:text-text-secondary hover:bg-bg-hover"}`}>
                            {f.label}
                        </button>
                    ))}
                </div>
            )}

            {/* List */}
            <div className="flex-1 overflow-y-auto">
                {chatsLoading && displayList.length === 0 && (
                    <div className="flex flex-col gap-3 p-4">
                        {[...Array(6)].map((_, i) => (
                            <div key={i} className="flex gap-3 items-center" style={{ animationDelay: `${i * 0.08}s` }}>
                                <div className="skeleton w-11 h-11 rounded-full flex-shrink-0" />
                                <div className="flex-1 space-y-2">
                                    <div className="skeleton h-3 w-32 rounded" />
                                    <div className="skeleton h-2.5 w-48 rounded" />
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {!chatsLoading && displayList.length === 0 && (
                    <div className="flex flex-col items-center justify-center py-16 gap-2 text-center px-4">
                        <div className="text-3xl mb-1">{search ? "🔍" : "💬"}</div>
                        <p className="text-sm font-medium text-text-secondary">
                            {search ? "Tidak ada hasil" : isContact ? "Belum ada kontak" : "Belum ada chat"}
                        </p>
                        {search && <p className="text-xs text-text-muted">Coba kata kunci lain</p>}
                    </div>
                )}

                {/* Pinned chats */}
                {pinned.length > 0 && (
                    <>
                        <div className="section-label">📌 PINNED</div>
                        {pinned.map(chat => (
                            <ChatItem
                                key={chat.jid}
                                chat={chat}
                                active={activeJid === chat.jid}
                                onClick={() => setActiveJid(chat.jid)}
                                isContact={isContact}
                            />
                        ))}
                    </>
                )}

                {/* Recent / All chats */}
                {recent.length > 0 && (
                    <>
                        {pinned.length > 0 && !isContact && (
                            <div className="section-label">RECENT</div>
                        )}
                        {recent.map(chat => (
                            <ChatItem
                                key={chat.jid}
                                chat={chat}
                                active={activeJid === chat.jid}
                                onClick={() => setActiveJid(chat.jid)}
                                isContact={isContact}
                            />
                        ))}
                    </>
                )}

                {/* Load more spacer */}
                <div className="h-4" />
            </div>
        </div>
    )
}
