import { useEffect, useCallback, useState } from "react"
import { useAuthStore } from "../store/auth"
import CountrySelect from "../components/CountrySelect"
import QRDisplay from "../components/QRDisplay"

// ── Icons ─────────────────────────────────────────────────
const ChatBubbleIcon = () => (
  <svg viewBox="0 0 28 28" fill="none" width="28" height="28">
    <path d="M14 2C7.373 2 2 7.373 2 14c0 2.386.69 4.61 1.884 6.492L2 26l5.7-1.836A11.94 11.94 0 0014 26c6.627 0 12-5.373 12-12S20.627 2 14 2z" fill="white" fillOpacity=".9" />
    <circle cx="9" cy="14" r="1.4" fill="#1da851" />
    <circle cx="14" cy="14" r="1.4" fill="#1da851" />
    <circle cx="19" cy="14" r="1.4" fill="#1da851" />
  </svg>
)

const PhoneIcon = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="5" y="2" width="14" height="20" rx="2" ry="2" />
    <line x1="12" y1="18" x2="12.01" y2="18" />
  </svg>
)

const QRIcon = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" />
    <rect x="3" y="14" width="7" height="7" /><rect x="14" y="14" width="3" height="3" />
    <line x1="21" y1="14" x2="21" y2="17" /><line x1="14" y1="21" x2="17" y2="21" />
  </svg>
)

const InfoIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ opacity: 0.55 }}>
    <circle cx="12" cy="12" r="10" /><line x1="12" y1="16" x2="12" y2="12" /><line x1="12" y1="8" x2="12.01" y2="8" />
  </svg>
)

const ErrorIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" className="text-red-error shrink-0">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z" />
  </svg>
)

const CheckIcon = () => (
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12" />
  </svg>
)

// ── Helpers ────────────────────────────────────────────────
function formatPhoneDisplay(dial, phone) {
  if (!phone) return `${dial} ···· ···· ···`
  const parts = phone.match(/.{1,4}/g) || []
  return `${dial} ${parts.join(" ")}`
}

// ── Step Indicator ─────────────────────────────────────────
const STEPS = [
  { n: 1, label: "Nomor WA" },
  { n: 2, label: "Verifikasi" },
  { n: 3, label: "Terhubung" },
]
function StepBar({ step }) {
  return (
    <div className="flex items-center justify-center gap-1 mb-7 px-4 py-2.5 bg-bg-secondary rounded-2xl border border-border">
      {STEPS.map((s, i) => (
        <div key={s.n} className="flex items-center gap-1">
          <div className="flex items-center gap-1.5">
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-bold transition-all duration-300
              ${step > s.n ? "bg-green-primary text-black" : step === s.n ? "bg-green-primary text-black shadow-[0_0_14px_rgba(37,211,102,0.4)]" : "bg-bg-hover text-text-muted"}`}>
              {step > s.n
                ? <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5"><polyline points="20 6 9 17 4 12" /></svg>
                : s.n}
            </div>
            <span className={`text-xs font-medium whitespace-nowrap transition-colors duration-200 ${step >= s.n ? "text-green-text" : "text-text-muted"}`}>{s.label}</span>
          </div>
          {i < STEPS.length - 1 && (
            <div className={`w-8 h-0.5 mx-1 rounded-full transition-all duration-300 ${step > s.n ? "bg-green-primary" : "bg-border"}`} />
          )}
        </div>
      ))}
    </div>
  )
}

// ── Main Auth Component ────────────────────────────────────
export default function Auth() {
  const {
    step, mode, phone, country, receivedCode, qrData,
    setPhone, setMode, setReceivedCode, setQRData, setStep,
    loading, setLoading, error, setError, setConnectedUser, reset,
  } = useAuthStore()

  // Listen to Electron IPC events
  useEffect(() => {
    if (!window.api) return
    window.api.onPairingCode((data) => {
      setLoading(false); setReceivedCode(data.code || ""); setStep(2)
    })
    window.api.onPairingError((err) => {
      setLoading(false); setError(err.message || "Gagal mendapatkan pairing code")
    })
    window.api.onQR((qr) => {
      setQRData(qr)
      if (mode === "qr") { setLoading(false); setStep(2) }
    })
    window.api.onConnected((data) => {
      setLoading(false); setConnectedUser(data); setStep(3)
    })
  }, [])

  const requestPairing = useCallback(() => {
    if (!phone || phone.length < 6) { setError("Masukkan nomor WhatsApp yang valid (min 6 digit)"); return }
    setLoading(true); setError(null)
    let clean = phone.replace(/\D/g, "")
    if (clean.startsWith("0")) clean = clean.slice(1)
    const full = country.dial.replace("+", "") + clean
    if (window.api) window.api.requestPairing(full)
    else setTimeout(() => { setLoading(false); setReceivedCode("A4B7-2X9K"); setStep(2) }, 2500)
  }, [phone, country])

  const startQR = useCallback(() => {
    setMode("qr"); setLoading(true); setError(null); setQRData(null)
    if (window.api) window.api.startQRMode()
    else setTimeout(() => { setLoading(false); setQRData("https://wa.me/qr/FAKEQRCODE12345"); setStep(2) }, 1800)
  }, [])

  const switchToQR = () => { setMode("qr"); setError(null); startQR() }
  const switchToPairing = () => { reset(); setMode("pairing") }

  return (
    <div className="h-screen w-screen flex flex-col items-center justify-center bg-bg-primary relative overflow-hidden">
      {/* Ambient orbs */}
      <div className="absolute top-[-15%] left-[-8%] w-[480px] h-[480px] rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(37,211,102,0.055) 0%, transparent 70%)" }} />
      <div className="absolute bottom-[-25%] right-[-12%] w-[560px] h-[560px] rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(37,211,102,0.04) 0%, transparent 70%)" }} />
      <div className="absolute top-[40%] right-[10%] w-[300px] h-[300px] rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(59,130,246,0.03) 0%, transparent 70%)" }} />

      {/* Card */}
      <div className="w-[520px] max-w-[95vw] glass-card rounded-[28px] p-9 relative z-10 shadow-[0_12px_52px_rgba(0,0,0,0.55)] animate-fade-in-scale">

        {/* Brand */}
        <div className="text-center mb-7 animate-fade-in-up">
          <div className="w-[60px] h-[60px] rounded-[18px] flex items-center justify-center mx-auto mb-4 animate-float"
            style={{ background: "linear-gradient(135deg,#25d366,#1da851)", boxShadow: "0 6px 24px rgba(37,211,102,0.35)" }}>
            <ChatBubbleIcon />
          </div>
          <h1 className="text-[28px] font-extrabold text-text-primary tracking-tight mb-1">
            Aurora<span className="text-green-text">Chat</span>
          </h1>
          <p className="text-xs text-text-muted">WhatsApp Desktop — Ringan &amp; Elegan</p>
        </div>

        {/* Step bar */}
        <StepBar step={step} />

        {/* ── STEP 1 ─────────────────────────────────── */}
        {step === 1 && (
          <div className="animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
            {/* Mode tabs */}
            <div className="flex gap-2 p-1.5 bg-bg-secondary rounded-[14px] border border-border mb-6">
              <button
                className={`mode-tab ${mode === "pairing" ? "active" : ""}`}
                onClick={() => { setMode("pairing"); setError(null) }}>
                <PhoneIcon /> Nomor HP
              </button>
              <button
                className={`mode-tab ${mode === "qr" ? "active" : ""}`}
                onClick={switchToQR}>
                <QRIcon /> QR Code
              </button>
            </div>

            {/* ── Pairing tab content ── */}
            {mode === "pairing" && (
              <div className="animate-tab-slide">
                <h2 className="text-xl font-bold text-text-primary mb-1.5">Masukkan Nomor WA</h2>
                <p className="text-sm text-text-secondary mb-5 leading-relaxed">
                  Masukkan nomor WhatsApp kamu. Pairing code akan dikirim untuk verifikasi.
                </p>

                <div className="flex gap-2.5 mb-2.5">
                  <CountrySelect />
                  <input
                    id="phone-input"
                    type="tel"
                    value={phone}
                    onChange={e => { setPhone(e.target.value.replace(/\D/g, "")); if (error) setError(null) }}
                    onKeyDown={e => e.key === "Enter" && phone.length >= 6 && requestPairing()}
                    placeholder="8xx xxxx xxxx"
                    className="flex-1 px-4 py-3 bg-bg-input border-[1.5px] border-border rounded-xl text-text-primary text-sm font-medium tracking-wider outline-none transition-all duration-150 placeholder:text-text-muted focus:border-green-primary focus:shadow-[0_0_0_3px_rgba(37,211,102,0.2)]"
                    autoFocus
                  />
                </div>

                <div className="flex items-center gap-1.5 text-[11px] text-text-muted mb-5 pl-0.5">
                  <InfoIcon />
                  <span>Tanpa awalan 0 — {formatPhoneDisplay(country.dial, phone)}</span>
                </div>

                {error && (
                  <div className="flex items-center gap-2 px-3 py-2.5 bg-red-error/10 border border-red-error/20 rounded-xl mb-4 animate-fade-in">
                    <ErrorIcon /><span className="text-sm text-red-error">{error}</span>
                  </div>
                )}

                <button
                  id="btn-request-pairing"
                  onClick={requestPairing}
                  disabled={loading || phone.length < 6}
                  className="w-full py-3.5 rounded-xl text-sm font-bold cursor-pointer transition-all duration-200 flex items-center justify-center gap-2 border-none text-black shadow-[0_4px_18px_rgba(37,211,102,0.3)] hover:shadow-[0_6px_28px_rgba(37,211,102,0.45)] hover:-translate-y-px active:translate-y-0 disabled:opacity-50 disabled:cursor-not-allowed disabled:translate-y-0"
                  style={{ background: "linear-gradient(135deg,#25d366,#1da851)" }}>
                  {loading && mode === "pairing"
                    ? <><div className="spinner" /> Memproses...</>
                    : <><PhoneIcon /> Minta Pairing Code</>}
                </button>
              </div>
            )}

            {/* ── QR tab content ── */}
            {mode === "qr" && (
              <div className="animate-tab-slide">
                <h2 className="text-xl font-bold text-text-primary mb-1.5">Scan QR Code</h2>
                <p className="text-sm text-text-secondary mb-5 leading-relaxed">
                  Scan QR Code di bawah menggunakan WhatsApp di HP kamu.
                </p>
                <QRDisplay data={qrData} loading={loading} />
                {error && (
                  <div className="flex items-center gap-2 px-3 py-2.5 bg-red-error/10 border border-red-error/20 rounded-xl mt-4 animate-fade-in">
                    <ErrorIcon /><span className="text-sm text-red-error">{error}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ── STEP 2 ─────────────────────────────────── */}
        {step === 2 && mode === "pairing" && (
          <div className="animate-fade-in-up">
            <h2 className="text-xl font-bold text-text-primary mb-1.5">Pairing Code</h2>
            <p className="text-sm text-text-secondary mb-5 leading-relaxed">
              Buka <span className="text-green-text font-medium">WhatsApp</span> di HP →
              Setelan → Perangkat Tertaut → Tautkan Perangkat → masukkan kode:
            </p>

            {receivedCode && (
              <div className="text-center mb-5">
                <p className="text-xs text-text-muted mb-3">Kode Pairing kamu</p>
                <div className="flex gap-1.5 justify-center flex-wrap">
                  {receivedCode.split("").map((c, i) => (
                    <div key={i} className="pairing-char w-11 h-13 bg-bg-input border-[1.5px] border-green-primary rounded-xl flex items-center justify-center text-xl font-bold text-green-text shadow-[0_0_10px_rgba(37,211,102,0.15)]">
                      {c}
                    </div>
                  ))}
                </div>
                <p className="text-xs text-text-muted mt-3 leading-relaxed">
                  Masukkan kode di atas ke WhatsApp di HP kamu.
                </p>
              </div>
            )}

            <div className="flex items-center justify-center gap-2.5 py-3 px-4 bg-bg-secondary rounded-xl border border-border mb-4">
              <div className="spinner spinner-green" />
              <span className="text-sm text-text-secondary">Menunggu verifikasi dari HP...</span>
            </div>

            {error && (
              <div className="flex items-center gap-2 px-3 py-2.5 bg-red-error/10 border border-red-error/20 rounded-xl mb-4 animate-fade-in">
                <ErrorIcon /><span className="text-sm text-red-error">{error}</span>
              </div>
            )}

            <button onClick={() => { reset() }}
              className="w-full py-3 rounded-xl text-sm font-semibold cursor-pointer transition-all duration-200 flex items-center justify-center gap-2 bg-transparent text-text-secondary border-[1.5px] border-border hover:border-text-muted hover:text-text-primary hover:bg-bg-hover">
              ← Kembali
            </button>
          </div>
        )}

        {step === 2 && mode === "qr" && (
          <div className="animate-fade-in-up">
            <h2 className="text-xl font-bold text-text-primary mb-1.5">Scan QR Code</h2>
            <p className="text-sm text-text-secondary mb-5 leading-relaxed">
              Scan QR Code menggunakan <span className="text-green-text font-medium">WhatsApp</span> di HP kamu.
            </p>
            <div className="mb-5"><QRDisplay data={qrData} loading={loading} /></div>
            {error && (
              <div className="flex items-center gap-2 px-3 py-2.5 bg-red-error/10 border border-red-error/20 rounded-xl mb-4 animate-fade-in">
                <ErrorIcon /><span className="text-sm text-red-error">{error}</span>
              </div>
            )}
            <button onClick={switchToPairing}
              className="w-full py-3 rounded-xl text-sm font-semibold cursor-pointer transition-all duration-200 flex items-center justify-center gap-2 bg-transparent text-text-secondary border-[1.5px] border-border hover:border-text-muted hover:text-text-primary hover:bg-bg-hover">
              <PhoneIcon /> Gunakan Pairing Code
            </button>
          </div>
        )}

        {/* ── STEP 3 ─────────────────────────────────── */}
        {step === 3 && (
          <div className="text-center py-4 animate-fade-in-up">
            <div className="w-[68px] h-[68px] rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce-in"
              style={{ background: "linear-gradient(135deg,#25d366,#1da851)", boxShadow: "0 6px 22px rgba(37,211,102,0.45)" }}>
              <CheckIcon />
            </div>
            <h2 className="text-xl font-bold text-green-text mb-2">Berhasil Terhubung! 🎉</h2>
            <p className="text-sm text-text-secondary">WhatsApp telah terhubung ke AuroraChat</p>
            <div className="flex items-center justify-center gap-2 mt-4">
              <div className="spinner spinner-sm spinner-green" />
              <span className="text-xs text-text-muted">Memuat chats...</span>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="text-center mt-6 pt-5 border-t border-border animate-fade-in" style={{ animationDelay: "0.4s" }}>
          <p className="text-[11px] text-text-muted leading-relaxed">
            AuroraChat menggunakan{" "}
            <a href="https://github.com/WhiskeySockets/Baileys" target="_blank" rel="noopener noreferrer"
              className="text-green-text no-underline hover:underline font-medium">Baileys</a>
            {" "}— Open Source WhatsApp Web API
          </p>
          <p className="text-[11px] text-text-muted mt-0.5">Bukan produk resmi WhatsApp Inc.</p>
        </div>
      </div>
    </div>
  )
}