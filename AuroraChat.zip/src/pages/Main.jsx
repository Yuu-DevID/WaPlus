import { useEffect, useRef } from "react"
import { useChatStore } from "../store/chat"
import { useAppStore } from "../store/app"
import Sidebar from "../components/Sidebar"
import ChatList from "../components/ChatList"
import ChatWindow from "../components/ChatWindow"
import ContactPanel from "../components/ContactPanel"

export default function Main() {
    const { setChats, setContacts, upsertChat, appendMessage } = useChatStore()
    const { activeJid, rightPanelOpen } = useAppStore()
    const loadedRef = useRef(false)

    // Load initial data
    useEffect(() => {
        if (loadedRef.current) return
        loadedRef.current = true

        // Load chats
        const loadChats = async () => {
            try {
                const res = await window.api?.dbChats?.({ limit: 80, offset: 0 })
                if (res?.ok) setChats(res.data, res.total)
            } catch (e) { console.error("Failed to load chats:", e) }
        }

        // Load contacts
        const loadContacts = async () => {
            try {
                const res = await window.api?.dbContacts?.({ limit: 200, offset: 0 })
                if (res?.ok) setContacts(res.data, res.total)
            } catch (e) { console.error("Failed to load contacts:", e) }
        }

        loadChats()
        loadContacts()

        // Listen to live updates
        if (window.api) {
            window.api.onChatsUpdated?.(() => loadChats())
            window.api.onContactsUpdated?.(() => loadContacts())
            window.api.onNewMessage?.((payload) => {
                if (payload.message) appendMessage(payload.chat_jid, payload.message)
                // Refresh chat to update last_msg
                loadChats()
            })
        }
    }, [])

    return (
        <div className="h-screen w-screen flex overflow-hidden bg-bg-primary">
            {/* Thin icon sidebar */}
            <Sidebar />

            {/* Chat list panel */}
            <div className="w-[288px] flex-shrink-0 flex flex-col border-r border-border bg-bg-sidebar animate-slide-in-left" style={{ animationDelay: "0.05s" }}>
                <ChatList />
            </div>

            {/* Main chat window */}
            <div className="flex-1 flex flex-col min-w-0 animate-fade-in" style={{ animationDelay: "0.1s" }}>
                {activeJid
                    ? <ChatWindow key={activeJid} />
                    : <WelcomeScreen />
                }
            </div>

            {/* Right contact panel */}
            {activeJid && rightPanelOpen && (
                <div className="w-[276px] flex-shrink-0 border-l border-border bg-bg-sidebar animate-slide-in-right">
                    <ContactPanel />
                </div>
            )}
        </div>
    )
}

function WelcomeScreen() {
    return (
        <div className="flex-1 flex flex-col items-center justify-center chat-bg gap-4">
            <div className="w-20 h-20 rounded-3xl flex items-center justify-center mb-2 animate-float"
                style={{ background: "linear-gradient(135deg,rgba(37,211,102,0.15),rgba(37,211,102,0.05))", border: "1px solid rgba(37,211,102,0.2)" }}>
                <svg viewBox="0 0 28 28" fill="none" width="36" height="36">
                    <path d="M14 2C7.373 2 2 7.373 2 14c0 2.386.69 4.61 1.884 6.492L2 26l5.7-1.836A11.94 11.94 0 0014 26c6.627 0 12-5.373 12-12S20.627 2 14 2z" fill="#25d366" fillOpacity=".5" />
                </svg>
            </div>
            <div className="text-center">
                <h2 className="text-lg font-bold text-text-primary mb-1">AuroraChat</h2>
                <p className="text-sm text-text-secondary max-w-[280px] leading-relaxed">
                    Pilih percakapan dari daftar untuk mulai chat
                </p>
            </div>
            <div className="flex items-center gap-2 mt-2 px-4 py-2 bg-bg-secondary rounded-full border border-border">
                <div className="w-2 h-2 rounded-full bg-green-primary animate-pulse" />
                <span className="text-xs text-green-text font-medium">Terhubung</span>
            </div>
        </div>
    )
}
