import { useEffect } from "react"
import { useAuthStore } from "./store/auth"
import { useAppStore } from "./store/app"
import Auth from "./pages/Auth"
import Main from "./pages/Main"

export default function App() {
  const { step, setConnectedUser, setStep } = useAuthStore()
  const { setConnectedUser: setAppUser } = useAppStore()

  // Listen for IPC events that affect routing
  useEffect(() => {
    if (!window.api) return
    window.api.onConnected?.((data) => {
      setConnectedUser(data)
      setAppUser(data)
      setStep(3)
    })
    window.api.onLoggedOut?.(() => {
      setStep(1)
    })
  }, [])

  return step === 3 ? <Main /> : <Auth />
}
